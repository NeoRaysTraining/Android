package com.itcs.example.togglebuttonexamplebymkhb;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    ToggleButton btn;
    //Switch aSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView)findViewById(R.id.image1);
        btn = (ToggleButton)findViewById(R.id.toggle_btn);
        btn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    imageView.setImageResource(R.drawable.selected_image);
                }
                else
                {
                    imageView.setImageResource(R.drawable.unselected_image);
                }
            }
        });
    }
}

